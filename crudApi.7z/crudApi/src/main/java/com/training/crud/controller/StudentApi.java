package com.training.crud.controller;

import java.util.ArrayList;

import java.util.List;

import com.training.crud.BusinessException;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.training.crud.domain.dto.StudentDto;
import com.training.crud.domain.inputForm.StudentRegisterForm;
import com.training.crud.domain.model.Course;
import com.training.crud.domain.model.Student;
import com.training.crud.domain.service.CourseService;
import com.training.crud.domain.service.StudentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/student")
public class StudentApi {

	private final StudentService studentService;
	private final CourseService courseService;

	@PostMapping("/register")
	public ResponseEntity<String> studentRegister(@Valid @RequestBody StudentRegisterForm studentRegisterForm,
			BindingResult br) {
		if (br.hasErrors()) {
			String errors = br.getAllErrors().stream().map(err -> err.getDefaultMessage())
					.reduce((msg1, msg2) -> msg1 + ", " + msg2).orElse("Validation errors occurred");
			throw new BusinessException(errors);
		}
		studentService.registerStudent(studentRegisterForm);
		return ResponseEntity.ok("Register Successful");
	}

	@GetMapping("/get-all")
	public ResponseEntity<List<StudentDto>> getStudents() {
		List<StudentDto> students = studentService.getStudents();
		return ResponseEntity.ok(students);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<String> updateStudent(@PathVariable("id") int id,
		@Valid @RequestBody StudentRegisterForm studentRegisterForm,BindingResult bindingResult ){
		if(bindingResult.hasErrors()) {
			return ResponseEntity.badRequest().build();
		}
		Student student = studentService.findById(id);
		if(student!=null) {
			
		}
		return ResponseEntity.ok("Update Successful");
	}
}
