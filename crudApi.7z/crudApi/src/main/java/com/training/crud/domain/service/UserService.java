package com.training.crud.domain.service;


import java.util.List;

import com.training.crud.domain.inputForm.UserRegisterForm;
import com.training.crud.domain.inputForm.UserSearchForm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;

import com.training.crud.domain.dto.UserDto;
import com.training.crud.domain.model.PageSetting;
import com.training.crud.domain.model.User;

import io.micrometer.common.lang.NonNull;


public interface UserService {

    User saveUser(UserRegisterForm userRegisterForm);

    User updateUser(int id,UserRegisterForm userRegisterForm);

    User deleteUser(int id);

    List<UserDto> getAllUser();

    Page<User> searchUserPage(UserSearchForm pageSetting);
}
