package com.training.crud.domain.service.impl;

import com.training.crud.BusinessException;
import com.training.crud.domain.enumreation.Role;
import com.training.crud.domain.inputForm.UserRegisterForm;
import com.training.crud.domain.inputForm.UserSearchForm;
import com.training.crud.domain.repository.UserRepository;
import com.training.crud.domain.dto.UserDto;
import com.training.crud.domain.dtomapper.UserDtoMapper;
import com.training.crud.domain.model.User;
import com.training.crud.domain.model.User_;
import com.training.crud.domain.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final UserDtoMapper userDtoMapper;

    @Override
    @Transactional
    public User saveUser(UserRegisterForm userRegisterForm) {
        /* Check if password and confirmed password match or not */
        if (userRegisterForm.getPassword().equals(userRegisterForm.getConfirmedPassword())) {

            if (userRepository.findByEmail(userRegisterForm.getEmail()).isPresent()) {
                throw new BusinessException("Email is already used.");
            }
            User user = new User();
            user.setName(userRegisterForm.getName());
            user.setPassword(userRegisterForm.getPassword());
            user.setEmail(userRegisterForm.getEmail());
            user.setRole(Role.USER);
            user.setIsActive(true);
            return userRepository.save(user);
        } else {
            throw new BusinessException("password and confirmed password do not match");
        }
    }

    @Override
    @Transactional
    public User updateUser(int id, UserRegisterForm userRegisterForm) {

        User user = userRepository.findById(id).orElseThrow(() -> new BusinessException("User not exists."));

        if (userRepository.isConflictEmailExist(user.getEmail(), userRegisterForm.getEmail()).isPresent()) {
            throw new BusinessException("Email is already used by other");
        }

        user.setName(userRegisterForm.getName());
        user.setEmail(userRegisterForm.getEmail());
        return userRepository.save(user);
    }

    @Override
    @Transactional
    public User deleteUser(int id) {
        User user = userRepository.findById(id).orElseThrow(() -> new BusinessException("User not exists."));
        user.setIsActive(false);
        return userRepository.save(user);
    }

    @Override
    public List<UserDto> getAllUser() {
        return userRepository.findAllByIsActiveTrue().stream().map(userDtoMapper::mapToUserDto).toList();
    }

    @Override
    public Page<User> searchUserPage(UserSearchForm pageSetting) {
        // TODO Auto-generated method stub
        if(pageSetting.getPage() < 1 || pageSetting.getElementPerPage() < 0 || pageSetting.getKey() == null){
            throw new BusinessException("Page size must not be less than one,Element per page must be positive number and Key must not be null");
        }
        Specification<User> spec = getUserSpecification(pageSetting);
        Sort userSort = pageSetting.buildSort();
        Pageable pageable = PageRequest.of(pageSetting.getPage()-1, pageSetting.getElementPerPage(), userSort);
        return userRepository.findAll(spec, pageable);
    }

    private static Specification<User> getUserSpecification(UserSearchForm pageSetting) {
        String name = pageSetting.getName();
        String role = pageSetting.getRole();

        Specification<User> spec = Specification.where(null);

        if (StringUtils.hasLength(name)) {
            spec = (root, query, builder) ->
                    builder.like(builder.lower(root.get(User_.name.getName())), "%" + name.toLowerCase().concat("%"));

        }
        if (StringUtils.hasLength(role)) {
            spec = spec.and((root, query, builder) ->
                    builder.equal(builder.lower(root.get(User_.role.getName())), role.toLowerCase()));
        }
        return spec;
    }
}
