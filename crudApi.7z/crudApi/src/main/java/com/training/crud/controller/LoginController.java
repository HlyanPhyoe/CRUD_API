package com.training.crud.controller;



import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@AllArgsConstructor
@RequestMapping("/api/auth")
public class LoginController {

    public String auth(){
        return "Here is Authentication Service";
    }
}
