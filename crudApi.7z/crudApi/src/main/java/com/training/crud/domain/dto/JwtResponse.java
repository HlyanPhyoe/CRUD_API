package com.training.crud.domain.dto;

import lombok.Data;

@Data
public class JwtResponse {
    private String email;
    private String accessToken;
    private String tokenType = "Bearer";
}
