package com.training.crud.domain.inputForm;

import com.training.crud.domain.model.PageSetting;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CourseSearchForm extends PageSetting {
    private String courseName;
}
