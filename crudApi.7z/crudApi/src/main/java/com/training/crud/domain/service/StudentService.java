package com.training.crud.domain.service;

import java.util.List;

import com.training.crud.domain.dto.StudentDto;
import com.training.crud.domain.inputForm.StudentRegisterForm;
import com.training.crud.domain.model.Student;

public interface StudentService {
	void registerStudent(StudentRegisterForm student);
	
	List<StudentDto> getStudents();
	Student findById(int id);
}
