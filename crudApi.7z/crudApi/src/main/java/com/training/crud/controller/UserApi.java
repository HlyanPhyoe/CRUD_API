package com.training.crud.controller;

import com.training.crud.BusinessException;
import com.training.crud.domain.dto.PageDto;
import com.training.crud.domain.dto.UserDto;
import com.training.crud.domain.dtomapper.PageToPageDTOMapper;
import com.training.crud.domain.inputForm.UserRegisterForm;
import com.training.crud.domain.inputForm.UserSearchForm;
import com.training.crud.domain.model.User;
import com.training.crud.domain.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/user")
public class UserApi {

    @Value("${mock.api.url}")
    private String mockApiUrl;

    private final UserService userService;
    private final PageToPageDTOMapper<User> pageDtoMapper;

    @PostMapping("/register")
    public ResponseEntity<String> userRegister(@Valid @RequestBody UserRegisterForm userRegisterForm, BindingResult br) {
        /* Check if user input correct or not */
        if (br.hasErrors()) {
            String errors = br.getAllErrors().stream().map(err -> err.getDefaultMessage()).reduce((msg1, msg2) -> msg1 + ", " + msg2).orElse("Validation errors occurred");
            throw new BusinessException(errors);
        }

        userService.saveUser(userRegisterForm);
        return ResponseEntity.ok("Register Successful");
    }

    @PostMapping("/delete-user/{id}")
    public ResponseEntity<HttpStatus> deleteUser(@PathVariable("id") int userId) {
        userService.deleteUser(userId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/get-all")
    public ResponseEntity<List<UserDto>> getAllUser() {
        List<UserDto> users = userService.getAllUser();
        return ResponseEntity.ok(users);
    }

    @PostMapping("/search-user")
    public PageDto<User> searchUser(@RequestBody UserSearchForm pageSetting) {
        return pageDtoMapper.pageToPageDTO(userService.searchUserPage(pageSetting));
    }

    @PutMapping("/update-user/{id}")
    public ResponseEntity<String> updateUser(@PathVariable("id") int id, @Valid @RequestBody UserRegisterForm userRegisterForm, BindingResult br) {
        if (br.hasErrors()) {
            String errors = br.getAllErrors().stream().map(err -> err.getDefaultMessage()).reduce((msg1, msg2) -> msg1 + ", " + msg2).orElse("Validation errors occurred");
            log.info("Error {} ", errors);
            throw new BusinessException(errors);
        }
        userService.updateUser(id, userRegisterForm);
        return ResponseEntity.ok("Update Successful");
    }


    @GetMapping("/mock-api")
    public ResponseEntity<?> callMockApi() throws URISyntaxException, IOException, InterruptedException {
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(mockApiUrl))
                .GET()
                .build();
        HttpResponse<String> response = httpClient.
                send(request, HttpResponse.BodyHandlers.ofString());
        return ResponseEntity.ok(response.headers() + "  " + response.statusCode() + "  " + response.body());

    }

    @PostMapping("/mock-api-post")
    public ResponseEntity<?> callPostMockApi(@RequestParam(required = false) String bodyPattern) throws URISyntaxException, IOException, InterruptedException {
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(mockApiUrl))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(bodyPattern))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        return ResponseEntity.ok("Status :" + response.statusCode());
    }

    @GetMapping("/async-mock-api")
    public ResponseEntity<?> callAsyncMockApi() throws URISyntaxException, ExecutionException, InterruptedException {
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(new URI(mockApiUrl))
                .GET()
                .build();
        CompletableFuture<HttpResponse<String>> futureResponse = httpClient.sendAsync(httpRequest, HttpResponse.BodyHandlers.ofString());
        HttpResponse<String> response = futureResponse.get();
        return ResponseEntity.ok("StatusCode : " + response.statusCode());
    }

    @GetMapping("/authenticate-mock-api")
    public ResponseEntity<?> callAuthenticateMockApi() throws IOException, InterruptedException {
        HttpClient httpClient = HttpClient.newBuilder()
                .authenticator(new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication("HlyanPhyoe", "waihlyanphyoe".toCharArray());
                    }
                }).build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(mockApiUrl))
                .POST(HttpRequest.BodyPublishers.ofString("12345"))
                .header("Authorization", "Basic " +
                        Base64.getEncoder().encodeToString(("waihlyanphyoe").getBytes()))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        return ResponseEntity.ok("Status Code :" + response.statusCode());
    }
}
