package com.training.crud.domain.dto;

import java.util.List;



import lombok.Data;

@Data
public class PageDto<T> {
	private List<T> content;
	private long totalElement;
}
