package com.training.crud.domain.repository;

import java.util.List;
import java.util.Optional;

import com.training.crud.domain.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.training.crud.domain.model.Course;

@Repository
public interface CourseRepository extends JpaRepository<Course, Integer>, JpaSpecificationExecutor<Course> {
	Optional<Course> findByName(String name);
	
	List<Course> findAllByStatusTrue();
	
}
