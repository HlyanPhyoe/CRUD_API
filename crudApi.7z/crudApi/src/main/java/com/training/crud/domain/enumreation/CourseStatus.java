package com.training.crud.domain.enumreation;


public enum CourseStatus {
    ACTIVE,PENDING,EXPIRED
}
