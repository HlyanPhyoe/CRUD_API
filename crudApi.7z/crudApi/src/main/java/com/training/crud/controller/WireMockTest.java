package com.training.crud.controller;


public class WireMockTest {
}
