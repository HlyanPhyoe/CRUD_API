package com.training.crud;

import lombok.experimental.StandardException;

@StandardException
public class BusinessException extends RuntimeException {
}
