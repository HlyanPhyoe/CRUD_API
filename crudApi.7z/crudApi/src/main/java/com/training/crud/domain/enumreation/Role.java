package com.training.crud.domain.enumreation;

public enum Role {
	ADMIN,USER;
}
