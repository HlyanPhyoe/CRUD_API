package com.training.crud.domain.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CourseDto {
	private String name;
	private String createdDate;
}
