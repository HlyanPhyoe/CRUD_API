package com.training.crud.domain.inputForm;



import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class StudentRegisterForm {
	@NotNull(message = "Name must not be empty.")
	private String name;
	
	@NotNull(message = "DOB must not be empty.")
	private String dob;
	
	@NotNull
	@Pattern(regexp = "Male|Female|Other", message = "Gender must be Male, Female, or Other")
	private String gender;
	
	@NotNull(message = "Phone Number must not be empty.")
	private String phone;
	
	@NotNull(message="Education must not be empty.")
	private String education;
	
	@NotNull
	@Size(min =1,message = "at least one course must be selected")
	private int courseId[];
}
