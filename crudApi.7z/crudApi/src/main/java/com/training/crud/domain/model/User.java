package com.training.crud.domain.model;

import com.training.crud.domain.enumreation.Role;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;

@Entity
@Table(name= "app_user")
@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor @Builder
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="name")
	private String name;
	private String email;
	private String password;
	
	@Enumerated(EnumType.STRING)
	private Role role;
	private Boolean isActive;
	
	/*
	 * @OneToMany(mappedBy = "user") private List<Course> courses;
	 */
	public User(String name,String email,String password,Role role,boolean isActive) {
		this.name = name;
		this.email =email;
		this.password = password;
		this.role = role;
		this.isActive= isActive;
	}
}
