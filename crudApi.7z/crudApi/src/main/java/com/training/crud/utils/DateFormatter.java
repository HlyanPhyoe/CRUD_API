package com.training.crud.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateFormatter {

	public static String convertLocalDateTimeToStringFormat(LocalDateTime createdDate) {
		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yy/MM/dd");
		 String formattedDateTime = createdDate.format(formatter);
		 return formattedDateTime;
	}
}
