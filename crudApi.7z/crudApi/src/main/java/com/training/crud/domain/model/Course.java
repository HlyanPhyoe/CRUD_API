package com.training.crud.domain.model;

import java.time.LocalDateTime;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.training.crud.domain.enumreation.CourseStatus;
import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "course")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Course {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;

	@CreatedDate
	@Column(name = "created_date", nullable = false, updatable = false)
	private LocalDateTime createdDate;
	
	@Column(name="update_date",nullable = true)
	@LastModifiedDate
	private LocalDateTime updateDate;

	@Enumerated(EnumType.STRING)
	private CourseStatus status;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	@JsonIgnore
	@ManyToMany(mappedBy = "courses")
	private List<Student> students;
}
