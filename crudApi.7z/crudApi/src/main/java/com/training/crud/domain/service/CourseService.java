package com.training.crud.domain.service;

import java.util.List;

import com.training.crud.domain.dto.CourseDto;
import com.training.crud.domain.inputForm.CourseRegisterForm;
import com.training.crud.domain.inputForm.CourseSearchForm;
import com.training.crud.domain.model.Course;
import org.springframework.data.domain.Page;

public interface CourseService {
	void addCourse(CourseRegisterForm courseRegisterForm);
	boolean isCourseAlreadyExist(String courseName);
	Course findByCourseId(int id);
	void deleteCourse(int id);
	List<CourseDto> getAllCourses();
	Page<Course> searchCoursePage(CourseSearchForm pageSetting);

	void updateCourse(int courseId,CourseRegisterForm courseRegisterForm);
}
