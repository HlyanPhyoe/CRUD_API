package com.training.crud.domain.inputForm;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CourseRegisterForm {
	@NotNull(message = "Name not be empty")
	private String name;
}
