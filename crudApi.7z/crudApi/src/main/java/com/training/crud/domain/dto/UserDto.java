package com.training.crud.domain.dto;

import com.training.crud.domain.model.User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


@Getter @Setter
@AllArgsConstructor
public class UserDto {
	private int id;
	private String name;
	private String email;
	private String role;

	
	public UserDto(User user) {
		this.id = user.getId();
		this.name = user.getName();
		this.email = user.getEmail();
		this.role = user.getRole().name();
	}
}
