package com.training.crud.domain.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import lombok.Data;

@Entity
@Data
@Table(name="student")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String dob;
	private String gender;
	private String phone;
	private String education;
	private Boolean isActive;
	
	@Version
	@Column(name = "version")
	private Long version;
	
	@ManyToMany(cascade = CascadeType.PERSIST)
	@JoinTable(name="student_has_course",joinColumns = {@JoinColumn(name="student_id")},
	inverseJoinColumns  = { @JoinColumn(name=" course_id") })
	@JsonBackReference
	private List<Course> courses;
	
}
