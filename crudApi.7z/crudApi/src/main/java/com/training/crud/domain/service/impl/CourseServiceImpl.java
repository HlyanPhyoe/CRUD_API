package com.training.crud.domain.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import com.training.crud.BusinessException;
import com.training.crud.domain.dtomapper.CourseDtoMapper;
import com.training.crud.domain.enumreation.CourseStatus;
import com.training.crud.domain.inputForm.CourseRegisterForm;
import com.training.crud.domain.inputForm.CourseSearchForm;
import com.training.crud.domain.inputForm.UserSearchForm;
import com.training.crud.domain.model.Course_;
import com.training.crud.domain.repository.CourseRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.training.crud.domain.dto.CourseDto;
import com.training.crud.domain.model.Course;
import com.training.crud.domain.service.CourseService;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService{

	private final CourseRepository courseRepository;
	private final CourseDtoMapper courseDtoMapper;

	@Override
	public void addCourse(CourseRegisterForm courseRegisterForm) {
		// TODO Auto-generated method stub
		if(courseRegisterForm.getName() != null) {
			if(!isCourseAlreadyExist(courseRegisterForm.getName()))
			{
				LocalDateTime now = LocalDateTime.now();
				Course course = new Course();
				course.setName(courseRegisterForm.getName());
				course.setCreatedDate(now);
				course.setStatus(CourseStatus.ACTIVE);
				courseRepository.save(course);
			}
			else throw new BusinessException("This course is already existed.");
		}
	}
	@Override
	public boolean isCourseAlreadyExist(String courseName) {
		// TODO Auto-generated method stub
		if(courseRepository.findByName(courseName).orElse(null)!=null)
			return true;
		
		return false;
	}
	@Override
	public Course findByCourseId(int id) {
		// TODO Auto-generated method stub
		return courseRepository.findById(id).orElse(null);
	}
	@Override
	public void deleteCourse(int id) {
		// TODO Auto-generated method stub
		Course course = courseRepository.findById(id).orElse(null);
		if(course!=null) {
			course.setStatus(CourseStatus.EXPIRED);
			courseRepository.save(course);
		}
	}
	@Override
	public List<CourseDto> getAllCourses() {
		// TODO Auto-generated method stub
		return courseRepository.findAllByStatusTrue().stream().map(courseDtoMapper::mapToCourseDto).toList();
	}

	@Override
	public Page<Course> searchCoursePage(CourseSearchForm pageSetting) {
		String name = pageSetting.getCourseName();

		Specification<Course> spec =null;
		if (name != null) {
			spec = (root, query, criteriaBuilder) ->
					criteriaBuilder.like(criteriaBuilder.lower(root.get(Course_.name.getName())), "%" +name.toLowerCase().concat("%"));
		}
		Sort corseSort = pageSetting.buildSort();
		Pageable pageable = PageRequest.of(pageSetting.getPage(),pageSetting.getElementPerPage(),corseSort);

		return courseRepository.findAll(spec,pageable);
	}

	@Override
	public void updateCourse(int courseId,CourseRegisterForm courseRegisterForm) {
			Course course = findByCourseId(courseId);
			if(course!=null) {
				LocalDateTime now = LocalDateTime.now();
				course.setName(courseRegisterForm.getName());
				course.setUpdateDate(now);
				courseRepository.save(course);
			}
	}

}
