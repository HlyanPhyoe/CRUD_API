package com.training.crud.domain.dtomapper;


import org.springframework.data.domain.Page;
import com.training.crud.domain.dto.PageDto;
import org.springframework.stereotype.Component;

@Component
public class PageToPageDTOMapper<T> {
	  public PageDto<T> pageToPageDTO(Page<T> page){
		  PageDto<T> pageDto = new PageDto<>();
		  pageDto.setContent(page.getContent());
		  pageDto.setTotalElement(page.getTotalElements());

	        return pageDto;
	  }
}
