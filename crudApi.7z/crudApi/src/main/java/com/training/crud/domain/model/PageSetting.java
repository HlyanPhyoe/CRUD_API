package com.training.crud.domain.model;


import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.data.domain.Sort;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
public class PageSetting {
	private int page;

    private int elementPerPage;

    private SortDirection direction;

    @NotNull
    private String key;

    
    public Sort buildSort() {
        if(direction==null)
            direction=SortDirection.ASC;
        switch (direction) {
            case DSC:
                return Sort.by(key).descending();
            case ASC:
                return Sort.by(key).ascending();
            default:
                log.warn("Invalid direction provided in PageSettings, using descending direction as default value");
                return Sort.by(key).descending();
        }
    }

    @Getter
    @AllArgsConstructor
    public enum SortDirection {
        DSC("dsc"), ASC("asc");

        private final String value;

    }

}
