package com.training.crud.domain.inputForm;

import com.training.crud.domain.model.PageSetting;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserSearchForm extends PageSetting {

    private String name;

    private String role;
}
