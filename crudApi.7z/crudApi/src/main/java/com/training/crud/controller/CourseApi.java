package com.training.crud.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.prefs.BackingStoreException;

import com.training.crud.BusinessException;
import com.training.crud.domain.dto.PageDto;
import com.training.crud.domain.dtomapper.PageToPageDTOMapper;
import com.training.crud.domain.inputForm.CourseSearchForm;
import com.training.crud.domain.model.PageSetting;
import com.training.crud.domain.model.User;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.crud.domain.dto.CourseDto;
import com.training.crud.domain.inputForm.CourseRegisterForm;
import com.training.crud.domain.model.Course;
import com.training.crud.domain.service.CourseService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/course")
@RequiredArgsConstructor 
public class CourseApi {
	private final CourseService courseService;
	private final PageToPageDTOMapper<Course> pageDtoMapper;
	
	@PostMapping("/add-course")
	public ResponseEntity<String> addCourse(@RequestBody @Validated CourseRegisterForm courseRegisterForm,
											BindingResult br){
		if(br.hasErrors()){
			String errors = br.getAllErrors().stream().map(err -> err.getDefaultMessage())
					.reduce((msg1, msg2) -> msg1 + ", " + msg2).orElse("Validation errors occurred");
			throw new BusinessException(errors);
		}
		courseService.addCourse(courseRegisterForm);
		return ResponseEntity.ok("Course Register Successful");
	}
	
	@PostMapping("/delete-course/{id}")
	public ResponseEntity<String> deleteCourse(@PathVariable("id") int id){
	
		if(courseService.findByCourseId(id)!=null) {
			courseService.deleteCourse(id);
			return ResponseEntity.ok("Deleted Course");
		}
		throw new BusinessException("This Course is not founded");
	}
	
	  @GetMapping("/get-all-course")
	  public ResponseEntity<List<CourseDto>> getAllCourses(){
		  try {
			  List<CourseDto> courses = courseService.getAllCourses();
			  return ResponseEntity.ok(courses);
		  }catch(Exception e) {
			  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		  }
	  }
	  
	  @PutMapping("/update-course/{id}")
	  public ResponseEntity<String> updateCourse(@PathVariable ("id") int id,@Valid @RequestBody CourseRegisterForm courseRegisterForm
	  ,BindingResult br){
		if(br.hasErrors()){
			String errors = br.getAllErrors().stream().map(err -> err.getDefaultMessage())
							.reduce((msg1, msg2) -> msg1 + ", " + msg2).orElse("Validation errors occurred");
			throw new BusinessException(errors);
		}
		courseService.updateCourse(id,courseRegisterForm);
		return ResponseEntity.ok("Update Successful");
	  }

	  @GetMapping("/search")
		public PageDto<Course> searchCourse(CourseSearchForm pageSetting){
			return pageDtoMapper.pageToPageDTO(courseService.searchCoursePage(pageSetting));
	  }
}
