package com.training.crud.domain.service.impl;

import java.util.ArrayList;
import java.util.List;

import com.training.crud.BusinessException;
import com.training.crud.domain.dtomapper.StudentDtoMapper;
import com.training.crud.domain.inputForm.StudentRegisterForm;
import com.training.crud.domain.model.Course;
import com.training.crud.domain.repository.StudentRepository;
import com.training.crud.domain.service.CourseService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.training.crud.domain.dto.StudentDto;
import com.training.crud.domain.model.Student;
import com.training.crud.domain.service.StudentService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {

	private final StudentRepository studentRepository;
	private final StudentDtoMapper studentDtoMapper;

	private final CourseService courseService;

	@Override
	public void registerStudent(StudentRegisterForm studentRegisterForm) {
		List<Course> courses = new ArrayList<Course>();
		Student student = new Student();
		student.setName(studentRegisterForm.getName());
		student.setDob(studentRegisterForm.getDob());
		student.setEducation(studentRegisterForm.getEducation());
		student.setGender(studentRegisterForm.getGender());
		student.setPhone(studentRegisterForm.getPhone());
		for (int id : studentRegisterForm.getCourseId()) {
			Course course = courseService.findByCourseId(id);
			if (course == null) {
				throw new BusinessException("This Course is not existed.");
			}
			courses.add(course);
		}
		student.setIsActive(true);
		student.setCourses(courses);

		// TODO Auto-generated method stub
		studentRepository.save(student);
	}

	@Override
	public List<StudentDto> getStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAllByIsActiveTrue().stream().map(studentDtoMapper::mapToStudentDto).toList();
	}

	@Override
	public Student findById(int id) {
		// TODO Auto-generated method stub
		return studentRepository.findById(id).orElse(null);
	}

}
