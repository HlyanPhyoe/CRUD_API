package com.training.crud.domain.dtomapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.training.crud.domain.dto.StudentDto;
import com.training.crud.domain.model.Course;
import com.training.crud.domain.model.Student;

@Component
public class StudentDtoMapper {
	public StudentDto mapToStudentDto(Student student) {
		return StudentDto.builder()
				.name(student.getName())
				.dob(student.getDob())
				.phoneNumber(student.getPhone())
				.courses(getCourseNameList(student.getCourses()))
				.build();
	}
	
	private List<String> getCourseNameList(List<Course> courses){
		List<String> courseNames = new ArrayList<String>();
		if(courses!=null) {
			for (Course course : courses) {
				courseNames.add(course.getName());
			}
		}
		return courseNames;
	}

}
