package com.training.crud.domain.dtomapper;

import org.springframework.stereotype.Service;

import com.training.crud.domain.dto.CourseDto;
import com.training.crud.domain.model.Course;
import com.training.crud.utils.DateFormatter;

@Service
public class CourseDtoMapper {
	
	public CourseDto mapToCourseDto(Course course) {

		return CourseDto.builder()
				.name(course.getName())
				.createdDate(DateFormatter.convertLocalDateTimeToStringFormat(course.getCreatedDate()))
				.build();
	}

}
