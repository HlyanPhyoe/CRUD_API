package com.training.crud.domain.dtomapper;

import org.springframework.stereotype.Service;

import com.training.crud.domain.dto.UserDto;
import com.training.crud.domain.model.User;

@Service
public class UserDtoMapper {
	
	public UserDto mapToUserDto(User user) {
		return new UserDto(user);
	}
}
