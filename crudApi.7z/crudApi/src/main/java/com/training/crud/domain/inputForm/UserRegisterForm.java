package com.training.crud.domain.inputForm;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor  @Builder
public class UserRegisterForm {
    @NotBlank(message = "Name must not be blank.")
    private String name;

    @NotBlank(message = "Email must not be blank.")
    @Email(message = "Email address must be valid")
    /*@Pattern(regexp = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
            message = "Email address must be valid")*/
    private String email;

    @NotBlank(message = "Password must not be empty.")
    private String password;

    @NotBlank(message = "Confirmed Password must not be empty.")
    private String confirmedPassword;

}
