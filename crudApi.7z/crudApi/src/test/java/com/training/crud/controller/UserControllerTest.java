package com.training.crud.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.crud.domain.dtomapper.PageToPageDTOMapper;
import com.training.crud.domain.enumreation.Role;
import com.training.crud.domain.inputForm.UserRegisterForm;
import com.training.crud.domain.model.User;
import com.training.crud.domain.service.UserService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;


import javax.print.attribute.standard.Media;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(UserApi.class)
public class UserControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @MockBean
    private PageToPageDTOMapper dtoMapper;


    @Test
    public void whenRequestGetAllUser_thenReturnResponseIsOk() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                .get("/user/get-all")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
    @Test
    public void userRegisterTest() throws Exception {
        UserRegisterForm user = UserRegisterForm.builder()
                .name("kyawgyi")
                .email("kyawgyi@gmail.com")
                .password("kyawgyi")
                .confirmedPassword("kyawgyi")
                .build();
        mockMvc.perform(MockMvcRequestBuilders
                .post("/user/register")
                .content(asJsonString(user))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void whenSearchUser_thenReturnResponseIsOk() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                .get("/user/search-user")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void whenDeleteUser_thenReturnResponseIsOk() throws Exception {
        User user = User.builder()
                .id(1)
                .name("mgmg")
                .email("mgm@gmail.com")
                .password("mgmg12345")
                .isActive(true)
                .role(Role.USER)
                .build();
        mockMvc.perform(MockMvcRequestBuilders
                .post("/user/delete-user/"+user.getId())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }
    @Test
    public void whenUpdateUser_thenReturnResponseIsOk() throws Exception {
        User user  = User.builder()
                .id(1)
                .name("mgmg")
                .build();
        UserRegisterForm userRegisterForm = UserRegisterForm.builder()
                .name("kyawgyi")
                .email("kyawgyi@gmail.com")
                .password("kyawgyi")
                .confirmedPassword("kyawgyi")
                .build();
        mockMvc.perform(MockMvcRequestBuilders
                .put("/user/update-user/"+user.getId())
                        .content(asJsonString(userRegisterForm))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }


    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
