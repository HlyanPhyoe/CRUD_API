package com.training.crud.service;


import com.training.crud.BusinessException;
import com.training.crud.domain.dto.UserDto;
import com.training.crud.domain.dtomapper.UserDtoMapper;
import com.training.crud.domain.enumreation.Role;
import com.training.crud.domain.inputForm.UserRegisterForm;
import com.training.crud.domain.inputForm.UserSearchForm;
import com.training.crud.domain.model.User;
import com.training.crud.domain.repository.UserRepository;
import com.training.crud.domain.service.UserService;
import com.training.crud.domain.service.impl.UserServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock(name = "userRepositoryMock")
    private UserRepository userRepository;

    @Mock(name = "userServiceMock")
    private UserService userService;

    @Mock
    private UserDtoMapper userDtoMapper;

    @InjectMocks
    private UserServiceImpl userServiceImpl;


    @Test
    public void whenFindWithExistingId_ThenReturn_UserName(){
        when(userRepository.findById(1)).thenReturn(Optional.of(new User("mgmg", "mgmg@gmail.com", "mgmg123", Role.USER, true)));
        User user = userRepository.findById(1).orElse(null);

        verify(userRepository,times(1)).findById(1);

        assert user != null;
        assertEquals("mgmg",user.getName());
    }

    @Test
    public void whenFindWithNotExistingId_ThenReturn_Null(){

        when(userRepository.findById(100)).thenReturn(Optional.empty());

        // Call findById with the non-existent ID
        Optional<User> optionalUser = userRepository.findById(100);
        verify(userRepository, times(1)).findById(100);

        assertFalse(optionalUser.isPresent(), "Expected user to be null for non-existent ID");
    }

    @Test
    public void testMockWithAnswer(){
        when(userRepository.findById(anyInt())).thenAnswer((Answer<Optional<User>>) invocation ->{
            Integer id = invocation.getArgument(0);
            if(id==1){
                return Optional.of(new User("mgmg", "mgmg@gmail.com", "mgmg123", Role.USER, true));
            }
            return Optional.empty();
        });
        Optional<User> user1 = userRepository.findById(1);
        Optional<User> user2 = userRepository.findById(2);

        Mockito.verify(userRepository,times(1)).findById(1);
        Mockito.verify(userRepository,times(1)).findById(2);

        assertTrue(user1.isPresent());
        assertFalse(user2.isPresent());
    }

    @Test
    public void getAllUser_WhenUserListExist(){
        List<User> mockUsers = Stream.of(
                new User(1,"mgmg","mgmg@gmail.com","mgmg123",Role.USER,true),
                new User(2,"kyawkyaw","kyawkyaw@gmail.com","kyaw123",Role.USER,true)
        ).collect(Collectors.toList());
        when(userRepository.findAllByIsActiveTrue()).thenReturn(mockUsers);


        when(userDtoMapper.mapToUserDto(any(User.class))).thenAnswer(invocation -> {
            User user = invocation.getArgument(0);
            return new UserDto(user.getId(),user.getName(),user.getEmail(),user.getRole().name());
        });

        List<UserDto> userList =  userServiceImpl.getAllUser();
        verify(userRepository,times(1)).findAllByIsActiveTrue();
        verify(userDtoMapper,times(2)).mapToUserDto(any(User.class));
        assertEquals(2,userList.size());
    }

    @Test
    public void getAllUser_WhenUserListNotExist(){
        when(userRepository.findAllByIsActiveTrue()).thenReturn(Collections.emptyList());
        List<UserDto> userList = userServiceImpl.getAllUser();

        assertNotNull(userList);
        assertTrue(userList.isEmpty());

        verify(userRepository,times(1)).findAllByIsActiveTrue();
        verify(userDtoMapper,never()).mapToUserDto(any(User.class));
    }
    @Test
    public void saveUserTest(){
        UserRegisterForm form = new UserRegisterForm("mgmg","mgmg@gmail.com","mgmg123","mgmg123");
        when(userRepository.findByEmail(form.getEmail())).thenReturn(Optional.empty());

        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            User user = invocation.getArgument(0);
            user.setId(1);
            user.setIsActive(true);
            return user;
        });

        User savedUser = userServiceImpl.saveUser(form);
        assertNotNull(savedUser);

        assertEquals("mgmg",savedUser.getName());
        assertEquals("mgmg@gmail.com",savedUser.getEmail());
        verify(userRepository,times(1)).findByEmail(form.getEmail());
        verify(userRepository,times(1)).save(any(User.class));
    }
    @Test
    public void whenSaveUserWithMisPassword_ThenThrowException(){
        UserRegisterForm form = new UserRegisterForm("mgmg","mgmg@gmail.com","mgmg123","mgmg");

        BusinessException exception = assertThrows(BusinessException.class,()-> userServiceImpl.saveUser(form));

        assertEquals("password and confirmed password do not match",exception.getMessage());
    }

    @Test
    public void whenSaveUserWithAlreadyExistEmail_ThenThrowException(){
        User mockUser = new User("mgmg","mgmg@gmail.com","mgmg123",Role.USER,true);
        UserRegisterForm form = new UserRegisterForm("kyawkyaw","mgmg@gmail.com","kyaw123","kyaw123");

        when(userRepository.findByEmail(form.getEmail())).thenReturn(Optional.of(mockUser));
        BusinessException exception = assertThrows(BusinessException.class,()-> userServiceImpl.saveUser(form));

        verify(userRepository,times(1)).findByEmail(form.getEmail());
        assertEquals("Email is already used.",exception.getMessage());

    }

    @Test
    public void updateUserTest(){
        int userId = 1;
        User mockUser = new User("mgmg","mgmg@gmail.com","mgmg123",Role.USER,true);
        UserRegisterForm form = new UserRegisterForm("updateName","update@gmail.com","updatepassword","updatepassword");
        when(userRepository.findById(userId)).thenReturn(Optional.of(mockUser));
        when(userRepository.isConflictEmailExist(mockUser.getEmail(),form.getEmail())).thenReturn(Optional.empty());

        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            return invocation.<User>getArgument(0);
        });

        User updatedUser = userServiceImpl.updateUser(userId,form);

        verify(userRepository,times(1)).findById(userId);

        assertEquals("updateName",updatedUser.getName());
        assertEquals("update@gmail.com",updatedUser.getEmail());
    }
    @Test
    public void whenUpdateUserWithNotExistingId_ThenThrowException(){
        int userId = 100;
        UserRegisterForm form = new UserRegisterForm("updateName","update@gmail.com","updatepassword","updatepassword");
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        BusinessException exception = assertThrows(BusinessException.class,()-> userServiceImpl.updateUser(userId,form));
        assertEquals("User not exists.",exception.getMessage());
    }
    @Test
    public void whenUpdateUserWithConflictEmailThatIsAlreadyExistByOther_ThenReturnException(){
        int userId = 1;
        User mockUser = new User("mgmg","mgmg@gmail.com","mgmg123",Role.USER,true);
        mockUser.setId(userId);

        UserRegisterForm form = new UserRegisterForm("updateName","mgmg@gmail.com","updatepassword","updatepassword");
        when(userRepository.findById(userId)).thenReturn(Optional.of(mockUser));
        when(userRepository.isConflictEmailExist(mockUser.getEmail(),form.getEmail())).thenReturn(Optional.of("email is used by other"));

        BusinessException exception = assertThrows(BusinessException.class,()->userServiceImpl.updateUser(userId,form));
        assertEquals("Email is already used by other",exception.getMessage());
    }

    @Test
    public void deleteUserTest(){
        int userId = 1;
        User mockUser = new User("mgmg","mgmg@gmail.com","mgmg123",Role.USER,true);
        mockUser.setId(userId);

        when(userRepository.findById(userId)).thenReturn(Optional.of(mockUser));
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            return invocation.<User>getArgument(0);
        });

        User deletedUser = userServiceImpl.deleteUser(userId);
        assertFalse(deletedUser.getIsActive());
    }

    @Test
    public void whenDeleterUserWithNotExistId_ThenThrowException(){
        int userId = 10;
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        BusinessException exception = assertThrows(BusinessException.class , ()-> userServiceImpl.deleteUser(userId));

        assertEquals("User not exists.",exception.getMessage());
    }


    @Test
    public void whenSearchUserWithOutAttribute_ThenReturnPage(){
        UserSearchForm pageSetting = new UserSearchForm();
        pageSetting.setPage(1);
        pageSetting.setKey("name");
        pageSetting.setElementPerPage(5);

        List<User> userList = Arrays.asList(
                new User("mgmg","mgmg@gmail.com","mgmg123",Role.USER,true),
                new User("kyawkyaw","kyawkyaw@gmail.com","kyawkyaw",Role.USER,true)
        );
        when(userRepository.findAll(any(Specification.class),any(Pageable.class))).thenReturn(new PageImpl(userList));

        Page<User> pageResult = userServiceImpl.searchUserPage(pageSetting);

        verify(userRepository,times(1)).findAll(any(Specification.class),any(Pageable.class));

        assertNotNull(pageResult);
    }
    @Test
    public void whenSearchUserByPageZero_ThenThrowException(){
        UserSearchForm pageSetting = new UserSearchForm();

        BusinessException exception = assertThrows(BusinessException.class,()-> userServiceImpl.searchUserPage(pageSetting));
        assertEquals("Page size must not be less than one,Element per page must be positive number and Key must not be null",exception.getMessage());
    }
    @Test
    public void whenSearchUserByKeyValueNull_ThenThrowException(){
        UserSearchForm pageSetting = new UserSearchForm();
        pageSetting.setPage(1);

        BusinessException exception = assertThrows(BusinessException.class,()-> userServiceImpl.searchUserPage(pageSetting));
        assertEquals("Page size must not be less than one,Element per page must be positive number and Key must not be null",exception.getMessage());
    }


}
