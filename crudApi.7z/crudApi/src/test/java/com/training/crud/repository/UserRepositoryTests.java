package com.training.crud.repository;

import com.training.crud.domain.enumreation.Role;
import com.training.crud.domain.model.User;
import com.training.crud.domain.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

@DataJpaTest
@Slf4j
public class UserRepositoryTests {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TestEntityManager entityManager;



    @BeforeEach
    public void setUp(){
        User user = new User();
        user.setName("testuser");
        user.setEmail("testuser@gmail.com");
        user.setPassword("testuser");
        user.setIsActive(true);
        user.setRole(Role.USER);
        entityManager.persist(user);

        User otherUser = new User();
        otherUser.setName("otherUser");
        otherUser.setEmail("otheruser@gmail.com");
        otherUser.setPassword("otheruser");
        otherUser.setIsActive(true);
        otherUser.setRole(Role.USER);
        entityManager.persist(otherUser);

    }

    @Test
    public void whenFindByUserEmail_thenReturnUser(){
        String email = "testuser@gmail.com";
        User found = userRepository.findByEmail("testuser@gmail.com").orElse(null);
        assertThat(found.getEmail()).isEqualTo(email);
        assertThat(found.getName()).isEqualTo("testuser");
        assertThat(found.getRole().name()).isEqualTo("USER");
    }

    @Test
    public void whenFindByNonExistingUserEmail_thenReturnNull(){
        String email = "nonexistinguser@gmail.com";
        User found = userRepository.findByEmail(email).orElse(null);
        assertNull(found);
    }
    @Test
    /*Testing when user do not change the email in update process*/
    public void whenUseOwnEmailInUpdate_thenReturnNull(){
        String email = "testuser@gmail.com";
        String returnEmail = userRepository.isConflictEmailExist("testuser@gmail.com",email).orElse(null);
        assertNull(returnEmail);
    }
    @Test
    /*Testing when user change other's user email in update process*/
    public void whenUseOtherAlreadyExistEmail_thenReturnExistEmail(){
        String email = "otheruser@gmail.com";
        String returnEmail = userRepository.isConflictEmailExist("testuser@gmail.com",email).orElse(null);
        assertThat(returnEmail).isEqualTo("otheruser@gmail.com");
    }
    @Test
    public void whenUseNewEmailNotAlreadyExist_thenReturnNull(){
        String email ="new123@gmail.com";
        String returnEmail = userRepository.isConflictEmailExist("testuser@gmail.com",email).orElse(null);
        assertNull(returnEmail);
    }

    @AfterEach
    public void tearDown(){
      User user = userRepository.findByEmail("testuser@gmail.com").orElse(null);
      User otherUser = userRepository.findByEmail("otheruser@gmail.com").orElse(null);
      if(user!=null)
          entityManager.remove(user);
      if(otherUser!=null)
          entityManager.remove(otherUser);
    }
}
