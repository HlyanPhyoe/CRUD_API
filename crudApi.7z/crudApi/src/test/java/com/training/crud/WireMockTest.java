package com.training.crud;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

public class WireMockTest {
    private CloseableHttpClient httpClient;
    @BeforeEach
    void setUp() throws Exception{
         httpClient = HttpClients.createDefault();
    }
    @Test
    void testWireMock() throws IOException {
        HttpGet httpGet = new HttpGet("http://localhost:9090/employee");
        HttpResponse response = httpClient.execute(httpGet);
        Assertions.assertEquals(200,response.getStatusLine().getStatusCode());
        Assertions.assertEquals("application/json",response.getFirstHeader("Content-Type").getValue());
    }
    @Test
    void getStatusCodeTest() throws IOException {
        HttpGet request = new HttpGet("http://localhost:9090/send-me-file");
        CloseableHttpResponse response =(CloseableHttpResponse)  httpClient.execute(request);
        Assertions.assertEquals(200,response.getStatusLine().getStatusCode());
    }
}

