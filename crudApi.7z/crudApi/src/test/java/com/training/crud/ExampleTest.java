package com.training.crud;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;


@ExtendWith(MockitoExtension.class)
public class ExampleTest {
    @Mock
    HashMap<String,Integer> hashMap;

    @Captor
    ArgumentCaptor<String> key;

    @Captor
    ArgumentCaptor<Integer> value;

    @Test
    public void argumentCaptureTest(){
        hashMap.put("A",1);
        hashMap.put("B",2);

        verify(hashMap,times(2)).put(key.capture(),value.capture());

        List<String> keys = key.getAllValues();
        List<Integer> values = value.getAllValues();

        assertEquals(Arrays.asList("A","B"),keys);
        assertEquals(Arrays.asList(Integer.valueOf(1),Integer.valueOf(2)),values);

        assertEquals("A",keys.get(0));
    }
}
